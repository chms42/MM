﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Nakov.TurtleGraphics;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Turtle.Forward();

            int swidth = 800, sheight = 500;
            float curX, curY;
            int num;
            string binary;


            this.Text = "거북이를 2진수 표현하기";
            this.ClientSize = new System.Drawing.Size(swidth,sheight);

            num = int.Parse(tb_num.Text.ToString());
            binary = Convert.ToString(num, 2);
            curX = swidth / 2 - 50;
            curY = -50;


            Turtle.Delay = 200;
            for (int i = 0; i < binary.Length; i++)
            {
                Turtle.PenUp();
                Turtle.MoveTo(curX, curY);
                Turtle.PenDown();
                if ((num & 1) == 1)
                {
                    Turtle.PenColor = Color.Red;
                    Turtle.PenSize = 10;
                    Turtle.Forward(80);

                }
                else
                {
                    Turtle.PenColor = Color.Blue;
                    Turtle.PenSize = 5;
                    Turtle.Forward(40);
                }
                curX -= 50;
                num >>= 1;
            }
          
            //Turtle.Delay = 500;

            //Turtle.Rotate(45);
            //Turtle.Forward(100);
            //Turtle.Rotate(45);
            //Turtle.Backward(100);

            //Turtle.PenColor = Color.Aqua;
            //Turtle.PenUp();
            //Turtle.MoveTo(-150, 0);
            //for (int i = 0; i < 9; i++) 
            {
                //Turtle.PenDown();
                //Turtle.Rotate(20);
                //Turtle.Forward(50);

                //Turtle.PenDown();
                //Turtle.Rotate(20);
                //Turtle.Forward(50);
            }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Turtle.Init();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Turtle.Forward();

            int swidth = 800, sheight = 500;
            float curX, curY;
            int num1;
            string binary;

            this.Text = "거북이로 비트 논리합 표현하기";
            this.ClientSize = new System.Drawing.Size(swidth, sheight);

            num1 = int.Parse(tb_num2.Text.ToString());
            binary = Convert.ToString(num1, 2);
            curX = swidth / 2 - 100;
            curY = -100;

           


            Turtle.Delay = 200;
            for (int i = 0; i < binary.Length; i++)
            {
                Turtle.PenUp();
                Turtle.MoveTo(curX, curY);
                Turtle.PenDown();
                if ((num1 & 1) == 1)
                {
                    Turtle.PenColor = Color.Green;
                    Turtle.PenSize = 10;
                    Turtle.Forward(80);

                }
                else
                {
                    Turtle.PenColor = Color.Brown;
                    Turtle.PenSize = 5;
                    Turtle.Forward(40);
                }
                curX -= 50;
                num1 >>= 1;
            }
        }
    }
}
